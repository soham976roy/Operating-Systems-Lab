#include "types.h"
#include "stat.h"
#include "user.h"

int main(void){
    printf(1,"Total Number of proccess running in the system = %d\n",getNumProc());
    exit();
}